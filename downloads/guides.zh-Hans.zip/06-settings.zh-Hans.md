# 设置与更新

![PS5 Backup Center](assets/brand-web.png)

TV / Web: **设置**.

可选择19种语言与八种主题。界面音效、背景音乐和音量分别控制。更改关联前检查来源、忽略项目、用户与设备。更新说明可重新阅读各版本变更，致谢包含组件作者、许可证和来源。


- [安排备份计划](15-plans.zh-Hans.md)
- [使用浏览器和后台引擎](16-web-engine.zh-Hans.md)
