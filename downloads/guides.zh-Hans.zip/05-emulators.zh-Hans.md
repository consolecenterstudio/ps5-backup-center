# 模拟器与ROM

![PS5 Backup Center](assets/brand-web.png)

TV / Web: **设置 / 来源与模拟器 / 游戏库**.

检查检测到的来源与各模拟器配置，确认ROM文件夹、配置文件和存档位置；恢复自动模式会重新使用检测结果。ROM详情仅选择实际提供的组件。ROM、即时存档与游戏存档不同。Switch/Eden需核对接收配置文件。
