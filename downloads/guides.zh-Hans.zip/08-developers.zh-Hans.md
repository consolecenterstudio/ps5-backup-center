# 开发者指南

![PS5 Backup Center](assets/brand-web.png)

TV / Web: **诊断与关于 / 致谢**.

引擎提供API与网页，管理清单、副本和持久任务；电视和浏览器是客户端。当前构建工具请参阅CONTRIBUTING。Mac预览不是主机运行测试。保留翻译参数并检查长文本、中日韩文字与阿拉伯语。详细API参考属于独立文档。
