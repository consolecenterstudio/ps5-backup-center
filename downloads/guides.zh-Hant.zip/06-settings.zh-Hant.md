# 設定與更新

![PS5 Backup Center](assets/brand-web.png)

TV / Web: **設定**.

可選擇19種語言與八種主題。介面音效、背景音樂和音量分別控制。變更關聯前檢查來源、忽略項目、使用者與裝置。更新說明可重新閱讀各版本變更，致謝包含元件作者、授權與來源。


- [安排備份計畫](15-plans.zh-Hant.md)
- [使用瀏覽器和背景引擎](16-web-engine.zh-Hant.md)
