# 開發者指南

![PS5 Backup Center](assets/brand-web.png)

TV / Web: **診斷與關於 / 致謝**.

引擎提供API與網頁，管理清單、副本與持久工作；電視和瀏覽器是用戶端。目前建置工具請參閱CONTRIBUTING。Mac預覽不是主機執行測試。保留翻譯參數並檢查長文字、中日韓文字與阿拉伯語。詳細API參考屬於獨立文件。
