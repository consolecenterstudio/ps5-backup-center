# 模擬器與ROM

![PS5 Backup Center](assets/brand-web.png)

TV / Web: **設定 / 來源與模擬器 / 遊戲庫**.

檢查偵測到的來源與各模擬器設定，確認ROM資料夾、設定檔和存檔位置；恢復自動模式會重新使用偵測結果。ROM詳細資料只選擇實際提供的元件。ROM、即時存檔與遊戲存檔不同。Switch/Eden需核對接收設定檔。
